import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { ShoppingBagIcon, MenuIcon, XIcon } from './icons';
import { STORE_NAME } from '../constants';
import './Header.css';

const Header: React.FC = () => {
  const { cartCount } = useAppContext();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const hasItems = cartCount > 0;

  const navLinks = [
    { path: '/', name: 'خانه' },
    { path: '/products', name: 'محصولات' },
    { path: '/about', name: 'درباره ما' },
    { path: '/bulk-order', name: 'خرید عمده' },
    { path: '/contact', name: 'ارتباط با ما' },
  ];

  return (
    <header className="header">
      <div className="header-container">
        <div className="header-content">
          <div className="header-logo">
            <Link to="/" className="header-logo-link">{STORE_NAME}</Link>
          </div>

          <nav className="header-nav">
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
              >
                {link.name}
              </NavLink>
            ))}
          </nav>

          <div className="header-actions">
            <div className="header-cart">
              <Link
                to="/cart"
                className={`header-cart-link${hasItems ? ' header-cart-link--active' : ''}`}
                aria-label={`سبد خرید${hasItems ? `، ${cartCount} قلم` : ''}`}
              >
                <span className={`cart-icon-wrap${hasItems ? ' cart-icon-wrap--shake' : ''}`}>
                  <ShoppingBagIcon filled={hasItems} />
                </span>
                {hasItems && (
                  <span className="cart-badge" aria-live="polite">
                    {cartCount > 99 ? '99+' : cartCount}
                  </span>
                )}
              </Link>
            </div>

            <div className="header-nav-mobile">
              <button
                type="button"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                aria-label={isMenuOpen ? 'بستن منو' : 'باز کردن منو'}
                aria-expanded={isMenuOpen}
              >
                {isMenuOpen ? <XIcon /> : <MenuIcon />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="mobile-menu">
          <nav className="mobile-menu-nav">
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) => (isActive ? 'mobile-menu-link active' : 'mobile-menu-link')}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.name}
              </NavLink>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
