
export const STORE_NAME = " فروشگاه آربی ";

// مدل‌های محصول
export const MODELS = [
  'اردکی',
  'لاله',
  'تالیا',
  'قاصدک',
  'قاجاری',
  'بامبو',
  'علم',
  'سایر',
];

// انواع محصول (نوع کالا) — برای فیلتر لیست
export { GOODS_TYPES as TYPES, SPEC_COLORS as COLORS } from './productSpecs';

// تگ‌های محصول
export const TAGS = ['اقتصادی', 'پرفروش', 'جدید'];

/** برندهای محصول */
export const BRANDS = [
  'تانسو',
  'قهرمان',
  'سایر',
] as const;

/** آستانه هشدار موجودی کم در پنل ادمین */
export const LOW_STOCK_THRESHOLD = 2;

// تصاویر پیش‌فرض برای هر مدل
export const DEFAULT_MODEL_IMAGES: { [key: string]: string } = {
  'اردکی': '/ordak.jpg',
  'لاله': '/lale.jpg',
  'بامبو': '/bambo.jpg',
  'تالیا': '/taliya.jpg',
  'قاصدک': '/gasedak.jpg',
  'قاجاری': '/ordak.jpg', // استفاده از تصویر پیش‌فرض تا زمانی که qajari.jpg اضافه شود
};

// تابع برای دریافت تصویر پیش‌فرض بر اساس مدل
export function getDefaultImage(model: string): string {
  return DEFAULT_MODEL_IMAGES[model] || '/loading.gif';
}